package com.hospital.servlet;

import com.hospital.model.Slot;
import com.hospital.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/slots")
public class SlotServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    public void init() throws ServletException {
        System.out.println("SlotServlet initialized at " + new java.util.Date());
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("doGet called with action: " + request.getParameter("action"));
        String action = request.getParameter("action");
        String lang = request.getParameter("lang") != null ? request.getParameter("lang") : "en";
        HttpSession session = request.getSession(false);

        try {
            if ("adminList".equals(action)) {
                if (session == null || !"admin".equals(session.getAttribute("role"))) {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                        java.net.URLEncoder.encode("Admin access required", "UTF-8") + "&lang=" + lang);
                    return;
                }
                List<Slot> slots = getAllSlots();
                request.setAttribute("slots", slots);
                request.getRequestDispatcher("/jsp/admin_slots.jsp").forward(request, response);
            } else if ("edit".equals(action)) {
                if (session == null || !"admin".equals(session.getAttribute("role"))) {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                        java.net.URLEncoder.encode("Admin access required", "UTF-8") + "&lang=" + lang);
                    return;
                }
                int slotId = Integer.parseInt(request.getParameter("slot_id"));
                Slot slot = getSlotById(slotId);
                if (slot == null) {
                    response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                        java.net.URLEncoder.encode("Slot not found", "UTF-8") + "&lang=" + lang);
                    return;
                }
                request.setAttribute("slot", slot);
                request.getRequestDispatcher("/jsp/edit_slot.jsp").forward(request, response);
            } else if ("delete".equalsIgnoreCase(action)) {
                if (session == null || !"admin".equals(session.getAttribute("role"))) {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                        java.net.URLEncoder.encode("Admin access required", "UTF-8") + "&lang=" + lang);
                    return;
                }
                int slotId = Integer.parseInt(request.getParameter("slot_id"));
                try (Connection conn = DBConnection.getConnection()) {
                    String checkSql = "SELECT COUNT(*) FROM AppointmentRequests WHERE slot_id = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                    checkStmt.setInt(1, slotId);
                    ResultSet rs = checkStmt.executeQuery();
                    rs.next();
                    if (rs.getInt(1) > 0) {
                        response.sendRedirect(request.getContextPath() + "/slots?action=adminList&error=" + 
                            java.net.URLEncoder.encode("Cannot delete slot with ID " + slotId + 
                            " due to " + rs.getInt(1) + " associated appointment requests.", "UTF-8") + "&lang=" + lang);
                        return;
                    }
                    String sql = "DELETE FROM AppointmentSlots WHERE slot_id = ?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setInt(1, slotId);
                    int rowsDeleted = ps.executeUpdate();
                    if (rowsDeleted > 0) {
                        System.out.println("Slot deleted: " + slotId);
                        response.sendRedirect(request.getContextPath() + "/slots?action=adminList&status=slot_deleted&lang=" + lang);
                    } else {
                        System.out.println("No slot found with ID: " + slotId);
                        response.sendRedirect(request.getContextPath() + "/slots?action=adminList&error=" + 
                            java.net.URLEncoder.encode("Slot not found", "UTF-8") + "&lang=" + lang);
                    }
                }
            } else if ("details".equals(action)) {
                String slotIdParam = request.getParameter("slot_id");
                System.out.println("Details action for slot_id: " + slotIdParam);
                if (session == null || session.getAttribute("user_id") == null) {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                        java.net.URLEncoder.encode("Please login to access this page", "UTF-8") + "&lang=" + lang);
                    return;
                }
                try {
                    int slotId = Integer.parseInt(slotIdParam);
                    Slot slot = getSlotById(slotId);
                    if (slot == null) {
                        System.out.println("Slot not found for slot_id: " + slotId);
                        response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                            java.net.URLEncoder.encode("Slot not found", "UTF-8") + "&lang=" + lang);
                        return;
                    }
                    request.setAttribute("slot", slot);
                    request.getRequestDispatcher("/WEB-INF/jsp/request_appointment.jsp").forward(request, response);
                } catch (NumberFormatException e) {
                    System.out.println("NumberFormatException: " + e.getMessage());
                    response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                        java.net.URLEncoder.encode("Invalid slot ID format: " + slotIdParam, "UTF-8") + "&lang=" + lang);
                } catch (SQLException e) {
                    System.out.println("SQLException: " + e.getMessage());
                    response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                        java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
                }
            } else {
                if (session == null || session.getAttribute("user_id") == null) {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                        java.net.URLEncoder.encode("Please login to access this page", "UTF-8") + "&lang=" + lang);
                    return;
                }
                String search = request.getParameter("search");
                List<Slot> slots = getAvailableSlots(search);
                request.setAttribute("slots", slots);
                request.getRequestDispatcher("/jsp/search_slots.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            System.out.println("SQLException in doGet: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException in doGet: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Invalid slot ID format", "UTF-8") + "&lang=" + lang);
        } catch (Exception e) {
            System.out.println("Unexpected Exception in doGet: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Unexpected error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("doPost called with action: " + request.getParameter("action"));
        String action = request.getParameter("action");
        String lang = request.getParameter("lang") != null ? request.getParameter("lang") : "en";
        HttpSession session = request.getSession(false);

        try {
            if (session == null || session.getAttribute("user_id") == null) {
                response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                    java.net.URLEncoder.encode("Please login to access this page", "UTF-8") + "&lang=" + lang);
                return;
            }
            if ("add".equals(action)) {
                if (!"admin".equals(session.getAttribute("role"))) {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                        java.net.URLEncoder.encode("Admin access required", "UTF-8") + "&lang=" + lang);
                    return;
                }
                String doctor = request.getParameter("doctor");
                String slotDate = request.getParameter("slot_date");
                String slotTime = request.getParameter("slot_time");
                try (Connection conn = DBConnection.getConnection()) {
                    String sql = "INSERT INTO AppointmentSlots (doctor, slot_date, slot_time, available) VALUES (?, ?, ?, TRUE)";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, doctor);
                    stmt.setString(2, slotDate);
                    stmt.setString(3, slotTime);
                    stmt.executeUpdate();
                    response.sendRedirect(request.getContextPath() + "/slots?action=adminList&status=slot_added&lang=" + lang);
                }
            } else if ("update".equals(action)) {
                if (!"admin".equals(session.getAttribute("role"))) {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                        java.net.URLEncoder.encode("Admin access required", "UTF-8") + "&lang=" + lang);
                    return;
                }
                int slotId = Integer.parseInt(request.getParameter("slot_id"));
                String doctor = request.getParameter("doctor");
                String slotDate = request.getParameter("slot_date");
                String slotTime = request.getParameter("slot_time");
                try (Connection conn = DBConnection.getConnection()) {
                    String sql = "UPDATE AppointmentSlots SET doctor = ?, slot_date = ?, slot_time = ? WHERE slot_id = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, doctor);
                    stmt.setString(2, slotDate);
                    stmt.setString(3, slotTime);
                    stmt.setInt(4, slotId);
                    int rowsUpdated = stmt.executeUpdate();
                    if (rowsUpdated > 0) {
                        response.sendRedirect(request.getContextPath() + "/slots?action=adminList&status=slot_updated&lang=" + lang);
                    } else {
                        response.sendRedirect(request.getContextPath() + "/slots?action=adminList&error=" + 
                            java.net.URLEncoder.encode("Slot not found", "UTF-8") + "&lang=" + lang);
                    }
                }
            } else if ("request".equals(action)) {
                if (!"patient".equals(session.getAttribute("role"))) {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                        java.net.URLEncoder.encode("Patient access required", "UTF-8") + "&lang=" + lang);
                    return;
                }
                int slotId = Integer.parseInt(request.getParameter("slot_id"));
                int userId = Integer.parseInt(session.getAttribute("user_id").toString());
                try (Connection conn = DBConnection.getConnection()) {
                    String checkSql = "SELECT available FROM AppointmentSlots WHERE slot_id = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                    checkStmt.setInt(1, slotId);
                    ResultSet rs = checkStmt.executeQuery();
                    if (!rs.next() || !rs.getBoolean("available")) {
                        response.sendRedirect(request.getContextPath() + "/slots?action=list&error=" + 
                            java.net.URLEncoder.encode("Slot is not available or does not exist", "UTF-8") + "&lang=" + lang);
                        return;
                    }
                    String sql = "INSERT INTO AppointmentRequests (user_id, slot_id, request_date, status, late_fee) VALUES (?, ?, ?, ?, 0.0)";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setInt(1, userId);
                    stmt.setInt(2, slotId);
                    stmt.setDate(3, new java.sql.Date(System.currentTimeMillis()));
                    stmt.setString(4, "pending");
                    stmt.executeUpdate();
                    response.sendRedirect(request.getContextPath() + "/slots?action=list&status=request_submitted&lang=" + lang);
                }
            } else {
                doGet(request, response);
            }
        } catch (SQLException e) {
            System.out.println("SQLException in doPost: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException in doPost: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Invalid slot ID format", "UTF-8") + "&lang=" + lang);
        } catch (Exception e) {
            System.out.println("Unexpected Exception in doPost: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Unexpected error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        }
    }

    private List<Slot> getAllSlots() throws SQLException {
        List<Slot> slots = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM AppointmentSlots";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Slot slot = new Slot();
                slot.setSlotId(rs.getInt("slot_id"));
                slot.setDoctor(rs.getString("doctor"));
                slot.setSlotDate(rs.getDate("slot_date"));
                slot.setSlotTime(rs.getTime("slot_time"));
                slot.setAvailable(rs.getBoolean("available"));
                slots.add(slot);
            }
        }
        return slots;
    }

    private List<Slot> getAvailableSlots(String search) throws SQLException {
        List<Slot> slots = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM AppointmentSlots WHERE available = TRUE";
            if (search != null && !search.trim().isEmpty()) {
                sql += " AND doctor LIKE ?";
            }
            PreparedStatement stmt = conn.prepareStatement(sql);
            if (search != null && !search.trim().isEmpty()) {
                stmt.setString(1, "%" + search.trim() + "%");
            }
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Slot slot = new Slot();
                slot.setSlotId(rs.getInt("slot_id"));
                slot.setDoctor(rs.getString("doctor"));
                slot.setSlotDate(rs.getDate("slot_date"));
                slot.setSlotTime(rs.getTime("slot_time"));
                slot.setAvailable(rs.getBoolean("available"));
                slots.add(slot);
            }
        }
        return slots;
    }

    private Slot getSlotById(int slotId) throws SQLException {
        Slot slot = null;
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM AppointmentSlots WHERE slot_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, slotId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                slot = new Slot();
                slot.setSlotId(rs.getInt("slot_id"));
                slot.setDoctor(rs.getString("doctor"));
                slot.setSlotDate(rs.getDate("slot_date"));
                slot.setSlotTime(rs.getTime("slot_time"));
                slot.setAvailable(rs.getBoolean("available"));
            }
        }
        return slot;
    }
}
