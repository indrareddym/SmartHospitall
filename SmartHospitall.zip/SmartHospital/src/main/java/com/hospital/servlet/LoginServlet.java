package com.hospital.servlet;

import com.hospital.util.DBConnection;
import org.mindrot.jbcrypt.BCrypt;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT user_id, password, role FROM Users WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String hashedPassword = rs.getString("password");
                if (BCrypt.checkpw(password, hashedPassword)) {
                    HttpSession session = request.getSession();
                    session.setAttribute("user_id", rs.getInt("user_id"));
                    session.setAttribute("role", rs.getString("role"));
                    String lang = request.getParameter("lang") != null ? request.getParameter("lang") : "en";
                    if ("admin".equals(rs.getString("role"))) {
                        response.sendRedirect(request.getContextPath() + "/slots?action=adminList&lang=" + lang);
                    } else {
                        response.sendRedirect(request.getContextPath() + "/slots?action=list&lang=" + lang);
                    }
                } else {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + java.net.URLEncoder.encode("Invalid username or password", "UTF-8") + "&lang=" + request.getParameter("lang"));
                }
            } else {
                response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + java.net.URLEncoder.encode("Invalid username or password", "UTF-8") + "&lang=" + request.getParameter("lang"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8"));
        }
    }
}