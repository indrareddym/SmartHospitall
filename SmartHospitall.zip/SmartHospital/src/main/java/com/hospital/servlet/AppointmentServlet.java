package com.hospital.servlet;

import com.hospital.model.AppointmentRequest;
import com.hospital.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet("/appointment")
public class AppointmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String lang = request.getParameter("lang") != null ? request.getParameter("lang") : "en";
        HttpSession session = request.getSession(false);

        try {
            if ("admin".equals(action)) {
                if (session == null || !"admin".equals(session.getAttribute("role"))) {
                    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                        java.net.URLEncoder.encode("Admin access required", "UTF-8") + "&lang=" + lang);
                    return;
                }
                List<AppointmentRequest> requests = getAllRequests();
                request.setAttribute("requests", requests);
                request.getRequestDispatcher("/jsp/admin_requests.jsp").forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                    java.net.URLEncoder.encode("Invalid action", "UTF-8") + "&lang=" + lang);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Unexpected error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String lang = request.getParameter("lang") != null ? request.getParameter("lang") : "en";
        HttpSession session = request.getSession(false);

        try {
            if (session == null || !"admin".equals(session.getAttribute("role"))) {
                response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                    java.net.URLEncoder.encode("Admin access required", "UTF-8") + "&lang=" + lang);
                return;
            }

            int requestId = Integer.parseInt(request.getParameter("request_id"));
            try (Connection conn = DBConnection.getConnection()) {
                if ("approve".equals(action)) {
                    // Update AppointmentRequests
                    String sql = "UPDATE AppointmentRequests SET status = ?, appointment_date = ? WHERE request_id = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, "approved");
                    stmt.setDate(2, new java.sql.Date(new Date().getTime())); // Current date
                    stmt.setInt(3, requestId);
                    int rowsUpdated = stmt.executeUpdate();

                    if (rowsUpdated > 0) {
                        // Mark slot as unavailable
                        String slotSql = "UPDATE AppointmentSlots SET available = FALSE WHERE slot_id = " +
                                         "(SELECT slot_id FROM AppointmentRequests WHERE request_id = ?)";
                        PreparedStatement slotStmt = conn.prepareStatement(slotSql);
                        slotStmt.setInt(1, requestId);
                        slotStmt.executeUpdate();
                        response.sendRedirect(request.getContextPath() + "/appointment?action=admin&status=request_updated&lang=" + lang);
                    } else {
                        response.sendRedirect(request.getContextPath() + "/appointment?action=admin&error=" + 
                            java.net.URLEncoder.encode("Request not found", "UTF-8") + "&lang=" + lang);
                    }
                } else if ("reject".equals(action)) {
                    String sql = "UPDATE AppointmentRequests SET status = ?, appointment_date = NULL WHERE request_id = ?";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, "rejected");
                    stmt.setInt(2, requestId);
                    int rowsUpdated = stmt.executeUpdate();
                    if (rowsUpdated > 0) {
                        response.sendRedirect(request.getContextPath() + "/appointment?action=admin&status=request_updated&lang=" + lang);
                    } else {
                        response.sendRedirect(request.getContextPath() + "/appointment?action=admin&error=" + 
                            java.net.URLEncoder.encode("Request not found", "UTF-8") + "&lang=" + lang);
                    }
                } else {
                    response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                        java.net.URLEncoder.encode("Invalid action", "UTF-8") + "&lang=" + lang);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Invalid request ID format", "UTF-8") + "&lang=" + lang);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Unexpected error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        }
    }

    private List<AppointmentRequest> getAllRequests() throws SQLException {
        List<AppointmentRequest> requests = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT ar.request_id, ar.user_id, ar.slot_id, ar.request_date, ar.appointment_date, ar.status, " +
                         "u.username, s.doctor " +
                         "FROM AppointmentRequests ar " +
                         "JOIN Users u ON ar.user_id = u.user_id " +
                         "JOIN AppointmentSlots s ON ar.slot_id = s.slot_id";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                AppointmentRequest request = new AppointmentRequest();
                request.setRequestId(rs.getInt("request_id"));
                request.setUserId(rs.getInt("user_id"));
                request.setSlotId(rs.getInt("slot_id"));
                request.setRequestDate(rs.getDate("request_date"));
                request.setAppointmentDate(rs.getDate("appointment_date"));
                request.setStatus(rs.getString("status"));
                request.setUsername(rs.getString("username"));
                request.setDoctor(rs.getString("doctor"));
                requests.add(request);
            }
        }
        return requests;
    }
}