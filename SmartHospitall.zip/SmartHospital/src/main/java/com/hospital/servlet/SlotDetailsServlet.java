package com.hospital.servlet;

import com.hospital.model.Slot;
import com.hospital.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

@WebServlet("/slotDetails")
public class SlotDetailsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String slotId = request.getParameter("slot_id");
        String lang = request.getParameter("lang") != null ? request.getParameter("lang") : "en";
        try {
            Slot slot = getSlotById(Integer.parseInt(slotId));
            if (slot == null || !slot.isAvailable()) {
                request.setAttribute("error", "Slot is not available or does not exist");
                request.getRequestDispatcher("/jsp/request_appointment.jsp").forward(request, response);
                return;
            }
            request.setAttribute("slot", slot);
            request.getRequestDispatcher("/jsp/request_appointment.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + java.net.URLEncoder.encode("Invalid slot ID format", "UTF-8") + "&lang=" + lang);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int slotId = Integer.parseInt(request.getParameter("slot_id"));
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("user_id");
        String lang = request.getParameter("lang") != null ? request.getParameter("lang") : "en";

        try (Connection conn = DBConnection.getConnection()) {
            String checkSql = "SELECT available FROM AppointmentSlots WHERE slot_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, slotId);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next() || !rs.getBoolean("available")) {
                response.sendRedirect(request.getContextPath() + "/jsp/request_appointment.jsp?slot_id=" + slotId + "&error=" + java.net.URLEncoder.encode("Slot is not available or does not exist", "UTF-8") + "&lang=" + lang);
                return;
            }

            String sql = "INSERT INTO AppointmentRequests (user_id, slot_id, request_date, status) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setInt(2, slotId);
            stmt.setDate(3, new java.sql.Date(new Date().getTime()));
            stmt.setString(4, "pending");
            stmt.executeUpdate();
            response.sendRedirect(request.getContextPath() + "/jsp/request_appointment.jsp?slot_id=" + slotId + "&status=requested&lang=" + lang);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + java.net.URLEncoder.encode("Invalid slot ID format", "UTF-8") + "&lang=" + lang);
        }
    }

    private Slot getSlotById(int slotId) throws SQLException {
        Slot slot = null;
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM AppointmentSlots WHERE slot_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, slotId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                slot = new Slot();
                slot.setSlotId(rs.getInt("slot_id"));
                slot.setDoctor(rs.getString("doctor"));
                slot.setSlotDate(rs.getDate("slot_date"));
                slot.setSlotTime(rs.getTime("slot_time"));
                slot.setAvailable(rs.getBoolean("available"));
            }
        }
        return slot;
    }
}