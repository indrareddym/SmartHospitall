package com.hospital.servlet;

import com.hospital.model.AppointmentRequest;
import com.hospital.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/history")
public class HistoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String lang = request.getParameter("lang") != null ? request.getParameter("lang") : "en";
        HttpSession session = request.getSession(false);

        try {
            if (session == null || session.getAttribute("user_id") == null) {
                response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=" + 
                    java.net.URLEncoder.encode("Please login to access this page", "UTF-8") + "&lang=" + lang);
                return;
            }

            int userId = Integer.parseInt(session.getAttribute("user_id").toString());
            List<AppointmentRequest> requests = getUserRequests(userId);
            request.setAttribute("requests", requests);
            request.getRequestDispatcher("/jsp/appointment_history.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Database error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Invalid user ID format", "UTF-8") + "&lang=" + lang);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/jsp/error.jsp?error=" + 
                java.net.URLEncoder.encode("Unexpected error: " + e.getMessage(), "UTF-8") + "&lang=" + lang);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response); // Handle POST as GET
    }

    private List<AppointmentRequest> getUserRequests(int userId) throws SQLException {
        List<AppointmentRequest> requests = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT ar.request_id, ar.user_id, ar.slot_id, ar.request_date, ar.appointment_date, ar.status, ar.late_fee, " +
                         "s.doctor " +
                         "FROM AppointmentRequests ar " +
                         "JOIN AppointmentSlots s ON ar.slot_id = s.slot_id " +
                         "WHERE ar.user_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                AppointmentRequest request = new AppointmentRequest();
                request.setRequestId(rs.getInt("request_id"));
                request.setUserId(rs.getInt("user_id"));
                request.setSlotId(rs.getInt("slot_id"));
                request.setRequestDate(rs.getDate("request_date"));
                request.setAppointmentDate(rs.getDate("appointment_date"));
                request.setStatus(rs.getString("status"));
                request.setLateFee(rs.getDouble("late_fee"));
                request.setDoctor(rs.getString("doctor"));
                requests.add(request);
            }
        }
        return requests;
    }
}