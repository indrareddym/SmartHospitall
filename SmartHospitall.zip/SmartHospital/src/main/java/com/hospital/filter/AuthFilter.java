package com.hospital.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter(urlPatterns = {"/slots/*", "/appointment/*", "/history/*", "/slotDetails/*"})
public class AuthFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        String lang = req.getParameter("lang") != null ? req.getParameter("lang") : "en";

        if (session == null || session.getAttribute("user_id") == null) {
            resp.sendRedirect(req.getContextPath() + "/jsp/login.jsp?error=" + java.net.URLEncoder.encode("Please login to access this page", "UTF-8") + "&lang=" + lang);
            return;
        }

        String role = (String) session.getAttribute("role");
        String uri = req.getRequestURI();
        String action = req.getParameter("action");

        if (uri.contains("/slots") && "adminList".equals(action) && !"admin".equals(role)) {
            resp.sendRedirect(req.getContextPath() + "/jsp/login.jsp?error=" + java.net.URLEncoder.encode("Admin access required", "UTF-8") + "&lang=" + lang);
            return;
        }
        if (uri.contains("/appointment") && "admin".equals(action) && !"admin".equals(role)) {
            resp.sendRedirect(req.getContextPath() + "/jsp/login.jsp?error=" + java.net.URLEncoder.encode("Admin access required", "UTF-8") + "&lang=" + lang);
            return;
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
    }
}